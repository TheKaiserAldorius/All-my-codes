<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
        }
        .message {
            text-align: center;
            font-size: 24px;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="message">
        <?php
        
        // Параметры подключения к базе данных
        $host = '192.168.101.238';
        $dbname = 'z1_db';
        $username = 'postgres';
        $password = 'masterkey';

        // Создание подключения к базе данных
        try {
            $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
            // Установка режима ошибок PDO на исключения
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Не удалось подключиться к базе данных: " . $e->getMessage());
        }

        // Получение данных из формы
        $regEmail = $_POST['regEmail'];
        $regSpeciality = $_POST['regSpeciality'];
        $regPassword = $_POST['regPassword'];
        $regConfirmPassword = $_POST['regConfirmPassword'];

        // Проверка совпадения паролей
        if ($regPassword !== $regConfirmPassword) {
            die("Пароли не совпадают");
        }

        // Хеширование пароля
        $hashedPassword = $regPassword;

        // Подготовка и выполнение SQL-запроса
        try {
            $sql = "INSERT INTO public.usr1 (Login_password_idUsers, email, speciality, password) VALUES (:login_password_idUsers, :email, :speciality, :password)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'login_password_idUsers' => $regEmail,
                'email' => $regEmail,
                'speciality' => $regSpeciality,
                'password' => $hashedPassword
            ]);
            echo "Регистрация успешно завершена!";
            echo '<script type="text/javascript">
                setTimeout(function() {
                    window.location.href = "login.html";
                }, 2000); // Переход произойдет через 2 секунды
            </script>';
        } catch (PDOException $e) {
            die("Ошибка при выполнении запроса: " . $e->getMessage());
        }
        ?>
    </div>
</body>
</html>