<?php
$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

try {
    
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $id_acc = $_POST['id_acc'];
        $email = $_POST['email'];
        $speciality = $_POST['speciality'];
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        $sql = "UPDATE public.usr1 SET email = :email, speciality = :speciality, password = :password WHERE id_acc = :id_acc";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'email' => $email,
            'speciality' => $speciality,
            'password' => $password,
            'id_acc' => $id_acc
        ]);

        header("Location: index.php");
        exit();
    } else {
        $id_acc = $_GET['id'];
        $sql = "SELECT email, speciality, password FROM public.usr1 WHERE id_acc = :id_acc";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['id_acc' => $id_acc]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
    }
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link rel="stylesheet" href="styles.css.all/editphp.css">
</head>
<body>
    <h1>Edit User</h1>
    <form method="POST">
        <input type="hidden" name="id_acc" value="<?php echo $row['id_acc']; ?>">
        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required><br>
        <label for="speciality">Speciality:</label>
        <input type="text" name="speciality" value="<?php echo htmlspecialchars($row['speciality']); ?>" required><br>
        <label for="password">Password:</label>
        <input type="password" name="password" required><br>
        <button type="submit">Обновить данные</button>
    </form>
</body>
</html>