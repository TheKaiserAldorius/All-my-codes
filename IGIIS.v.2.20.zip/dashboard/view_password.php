<?php
$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

try {
    
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $id_acc = $_GET['id'];
    $sql = "SELECT password FROM public.usr1 WHERE id_acc = :id_acc";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id_acc' => $id_acc]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    echo "Password: " . htmlspecialchars($row['password']);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>