<?php
session_start();

// Проверка, если пользователь не вошел как администратор
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Админ панель</title>
    <link rel="icon" href="images/logo_IGIIS_-180x180.gif" type="image/x-icon">
    <style>
        a{ 
            display: inline-block;
    padding: 10px 20px;
    background-color: #666;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: background-color 0.3s, box-shadow 0.3s;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            color: #333;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #444;
            padding: 40px 0;
            text-align: center;
        }
        header img {
            margin-bottom: -30px;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        h1 {
            color: #555;
        }
        .service-panel {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }
        .service {
            background-color: #e0e0e0;
            padding: 20px;
            border-radius: 5px;
            flex: 1;
            margin: 0 10px;
        }
        .service h2 {
            color: #444;
        }
        .service p {
            color: #666;
        }
        .service button, .service .bu1 {
            background-color: #666;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
        }
        .service button:hover, .service .bu1:hover {
            background-color: #555;
        }
        footer {
            background-color: #444;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <img src="images/logo_IGIIS_-180x180.png" alt="logo" height="80" width="80">
        <a href="logout.php">Выйти</a>
    </header>
    <div class="container">
        <h1>Добро пожаловать на сайт ИГИИС цифровые решения</h1>
        <p>Для администарации сайта и тех-поддержки:</p>
        <div class="service-panel">
            <div class="service">
                <h2>Аккаунты</h2>
                <p>Редактирование аккаунтов пользователей сайта со стороны сайта с подключением БД.</p>
                <form action="autputdb.php">
                    <input type="submit" value="Подробнее" class="bu1"/>
                </form>
            </div>
            <div class="service">
                <h2>Работы пользоватлей - глобальный просмотр</h2>
                <p>Доступ к просмотру и редактированию работ.</p>
                <form action="autputWorksdb.php" method="post">
                    <input type="hidden" name="firm" value="ИГИИС цифровые решения">
                    <input type="hidden" name="contract" value="Конструктор договора на выполнение инженерных изысканий">
                    <button type="submit">Подробнее</button>
                </form>
            </div>
        </div>
    </div>
    <footer>
        <div>
            <p style="text-align: center; margin-top:400px; color: white; font-size: 35px;">ИГИИС 2024</p>
        </div>
    </footer>
    <script defer src="index.js"></script>
</body>
</html>