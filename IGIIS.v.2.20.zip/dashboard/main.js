function showContent(page) {
    const contentDiv = document.getElementById('content');
    let content;

    switch (page) {
        case 'homeone':
            content = '<h1>Добропожаловать в ИГИИС!</h1>';
            break;
        case 'about':
            content = `
                <div>
                    <form action="" name="form-1" style="padding: 10px;">
                        <div>
                            <h1>Введите местоположение объекта</h1>
                            <label>Город</label><input type="text" placeholder="Введите город" name="city">
                            <label>Улица</label><input type="text" placeholder="Введите улицу" name="street">
                            <label>Дом</label><input type="text" placeholder="Введите номер дома" name="house">
                            <label>Корпус</label><input type="text" placeholder="Введите номер корпуса" name="corpus">
                            <label>Строение</label><input type="text" placeholder="Введите номер строения" name="building">
                            <input type="checkbox" id="locationCheckbox" onclick="toggleLocationField()"> Сведения о местоположении объекта
                            <textarea id="locationInfo" style="display: none;" placeholder="Ввести сведения, позволяющие определить местоположение объекта"></textarea>
                        </div>
                        <div>
                            <button type="button" class="u-btn1" onclick="saveForm()">Сохранить</button>
                        </div>
                    </form>
                </div>
            `;
            break;
        case 'contact':
            content = `
                <div>
                    <form action="" name="form-2" style="padding: 10px;">
                        <div>
                            <h1>Основание для выполнения работ</h1>
                            <label>Договор/Контракт/Инвестиционный проект/Инвестиционная программа</label>
                            <input type="text" placeholder="Введите документ" name="document">
                            <label>ММ/ДД/ГГГГ</label>
                            <input type="date" name="date">
                            <input type="checkbox" id="undefinedCheckbox" onclick="toggleUndefinedFields()"> Не определено
                        </div>
                        <div>
                            <button type="button" class="u-btn1" onclick="saveForm()">Сохранить</button>
                        </div>
                    </form>
                </div>
            `;
            break;
        case 'idworks':
            content = `
            
            <form action="" name="form-6" style="padding: 10px;">
            <h1>Идентификационные сведения о заказчике и исполнителе инженерных изысканий:</h1> 
        <form>
            <label for="inn">Реквизиты:</label>
            <input type="text" placeholder="ИНН" id="inn" name="inn" required>

            <label for="organization-name">Наименование организации/ИП:</label>
            <input type="text" placeholder="Наименование организации/ИП" id="organization-name" name="organization-name" required>

            <label for="legal-address">Юридический адрес:</label>
            <input type="text" placeholder="ОГРН" id="legal-address" name="legal-address" required>

            <label for="country-select">Страна:</label>
<select id="country-select" name="country">
    <option value="Россия">Россия</option>
    <option value="Украина">Украина</option>
    <option value="Белоруссия">Белоруссия</option>
    <option value="Казахстан">Казахстан</option>
    <option value="Казахстан">Таджикистан</option>
    <option value="Китай">Китай</option>
</select>

            <label for="actual-address">Фактический адрес:</label>
            <input type="text" id="actual-address" name="actual-address" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Телефон:</label>
            <input type="tel" id="phone" name="phone" required>

            <button type="button" class="u-btn1" onclick="saveForm()">Сохранить</button>
        </form>
    </form>`
            ;break;
        case 'type_of_works':
            content = '<h1>Виды инженерных изысканий</h1>';
            break;
        case 'drafts':
            content = '<h1>Черновики</h1>';
            break;
        case 'nameobject':
            content = `<form id="objectForm">
    <label for="name">Введите наименование:</label>
    <input type="text" placeholder="Введите наименование объекта" name="objectName">
    <button type="button" class="u-btn1" onclick="saveObject()">Сохранить</button>
</form>`;
            break;
        case 'worksosn':
            content = `
                <div>
                    <form action="" name="form-4" style="padding: 10px;">
                        <div>
                            <h1>Вид градостроительной деятельности</h1>
                            <select name="activityType">
                                <option value="planning">Подготовка документов территориального планирования</option>
                                <option value="documentation">Документация по планировке территории и выбора площадок(трасс) для строительства</option>
                                <option value="design">Архитектурно-строительное проектирование</option>
                                <option value="construction">Строительство</option>
                                <option value="operation">Эксплуатация</option>
                                <option value="reconstruction">Реконструкция</option>
                                <option value="demolition">Снос (ликвидация)</option>
                            </select>
                        </div>
                        <div>
                            <button type="button" class="u-btn1" onclick="saveForm()">Сохранить</button>
                        </div>
                    </form>
                </div>
            `;
            break;
        case 'who':
            content = `
                <div>
                    <form action="" name="form-5" style="padding: 10px;">
                        <div>
                            <h1>Сведения о земельном участке и землепользователях</h1>
                            <label>Кадастровый номер земельного участка</label>
                            <input type="text" placeholder="Формат ввода номера: ХХ:ХХ:XХХХХХХ:YYYYY, где количество знаков X - строгое, Y-нестрогое" name="cadastralNumber">
                            <input type="checkbox" id="gpzuCheckbox" onclick="toggleGpzuFields()"> Имеется градостроительный план земельного участка (ГПЗУ)
                            <div id="gpzuFields" style="display: none;">
                                <label>Номер ГПЗУ</label>
                                <input type="text" placeholder="Введите номер ГПЗУ" name="gpzuNumber">
                                <label>Дата выдачи ГПЗУ</label>
                                <input type="date" name="gpzuDate">
                            </div>
                        </div>
                        <div>
                            <button type="button" class="u-btn1" onclick="saveForm()">Сохранить</button>
                        </div>
                    </form>
                </div>
            `;
            break;
        default:
            content = '<h1>Добропожаловать в ИГИИС!</h1>';
            break;
    }

    contentDiv.innerHTML = content;
}

function toggleAccordion(element) {
    const panel = element.nextElementSibling;
    const isActive = panel.style.display === 'flex';
    panel.style.display = isActive ? 'none' : 'flex';
}

function toggleUndefinedFields() {
    const checkbox = document.getElementById('undefinedCheckbox');
    const form = checkbox.closest('form');
    const inputs = form.querySelectorAll('input[type="text"], input[type="date"]');

    inputs.forEach(input => {
        input.style.display = checkbox.checked ? 'none' : 'block';
    });
}

function toggleLocationField() {
    const checkbox = document.getElementById('locationCheckbox');
    const locationInfo = document.getElementById('locationInfo');
    const inputs = document.querySelectorAll('input[name="city"], input[name="street"], input[name="house"], input[name="corpus"], input[name="building"]');

    if (checkbox.checked) {
        inputs.forEach(input => input.style.display = 'none');
        locationInfo.style.display = 'block';
    } else {
        inputs.forEach(input => input.style.display = 'block');
        locationInfo.style.display = 'none';
    }
}

function toggleGpzuFields() {
    const checkbox = document.getElementById('gpzuCheckbox');
    const gpzuFields = document.getElementById('gpzuFields');
    gpzuFields.style.display = checkbox.checked ? 'block' : 'none';
}


function saveObject() {
    const objectName = document.querySelector('input[name="objectName"]').value;
    if (!objectName) {
        alert("Пожалуйста, введите наименование объекта.");
        return;
    }

    fetch('save_object.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ objectName })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Данные успешно сохранены!");
        } else {
            alert("Ошибка при сохранении данных: " + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert("Произошла ошибка при отправке данных.");
    });
}
