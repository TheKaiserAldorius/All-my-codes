
<?php


$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $id_acc = $_GET['id'];
    $sql = "DELETE FROM public.id_workstation WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);

    header("Location: tzoncreate.php");
    exit();
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?>
</body>
