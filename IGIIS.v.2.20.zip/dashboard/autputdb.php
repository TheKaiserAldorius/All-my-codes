<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр аккаунтов</title>
    <link rel="stylesheet" href="styles.css.all/autputdb.css">
    <link rel="icon" href="images/logo_IGIIS_-180x180.gif" type="image/x-icon">
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
    margin: 0;
    padding: 0;
}

h1 {
    color: #555;
    text-align: center;
    margin-top: 20px;
}

table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

th, td {
    padding: 12px 15px;
    text-align: left;
}

thead {
    background-color: #444;
    color: #fff;
}

tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

tbody tr:hover {
    background-color: #ddd;
}

a {
    color: #666;
    text-decoration: none;
}

a:hover {
    color: #555;
    text-decoration: underline;
}
</style>
<body>
    <h1>Таблица пользователей</h1>
    <table>
        <thead>
            <tr>
                <th>id_acc</th>
                <th>Email</th>
                <th>Speciality</th>
                <th>Password</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $host = '192.168.101.238';
            $dbname = 'z1_db';
            $username = 'postgres';
            $password = 'masterkey';

            try {
                $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "SELECT email, speciality, id_acc, password FROM public.usr1";

                $stmt = $pdo->prepare($sql);
                $stmt->execute();

                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($results as $row) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id_acc']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['speciality']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['password']) . "</td>";
                    echo "<td>";
                    echo "<a href='edit.php?id=" . $row['id_acc'] . "'>Редактировать</a> | ";
                    echo "<a href='delete.php?id=" . $row['id_acc'] . "'>Удалить</a> | ";
                    echo "</td>";
                    echo "</tr>";
                }

            } catch (PDOException $e) {
                echo "<tr><td colspan='5'>Connection failed: " . $e->getMessage() . "</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>