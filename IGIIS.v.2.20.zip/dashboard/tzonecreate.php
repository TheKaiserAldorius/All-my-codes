<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ИГИИС ЗАДАНИЕ</title>
    <link rel="stylesheet" href="styles.css.all/tzstyle.css">
    <lin rel="stylesheet" href="styles.css.all\modallogin.css">
    <link rel="icon" href="images/logo_IGIIS_-180x180.gif" type="image/x-icon">
    
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
    margin: 0;
    padding: 0;
}

h1 {
    color: #555;
    text-align: center;
    margin-top: 20px;
}

table {
    width: 80%;
    margin: 20px auto;
    border-collapse: collapse;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

th, td {
    padding: 12px 15px;
    text-align: left;
}

thead {
    background-color: #444;
    color: #fff;
}

tbody tr:nth-child(even) {
    background-color: #f2f2f2;
}

tbody tr:hover {
    background-color: #ddd;
}

a {
    color: #666;
    text-decoration: none;
}

a:hover {
    color: #555;
    text-decoration: underline;
}

.loginform1 {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        background-color: #f4f4f4;
    }

    .loginform1 form {
        background: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        text-align: center;
    }

    .loginform1 input[type="email"],
    .loginform1 input[type="password"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 5px;
    }

    .loginform1 button {
        width: 100%;
        padding: 10px;
        border: none;
        background-color: #5cb85c;
        color: white;
        border-radius: 5px;
        cursor: pointer;
    }

    .loginform1 button:hover {
        background-color: #4cae4c;
    }
  
.worksin {
    text-align: center;
    margin-bottom: -25px;
}

.form-input {
    width: 300px;
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-button {
    width: 200px;
    padding: 10px;
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    border-radius: 5px;
    color: #333;
    font-size: 16px;
}

   

</style>

<body>
   
<header>
<form action="loginwork.php" method="post" class="worksin">
    <input type="email" name="loginEmail" placeholder="Email" required class="form-input">
    <input type="password" name="loginPassword" placeholder="Password" required class="form-input">
    <button type="submit" class="form-button">Повторный логин</button>
</form>
    <div style="text-align: center;">
        <button class="btnpoppy" type="submit" onclick="window.location.href ='main.php';">На главную страницу!</button>
    </div>
    
</header>




    






    <div class="container">
        <div class="menu">
            <p></p>
            <div class="itemtableftmenu1" style="display: block;">
                <button  onclick="showContent('homeone')">Главная</button>
            </div>
            <div class="itemtableftmenu" style="display: block;">
                <div class="accordionactive1 active" onclick="toggleAccordion(this)">
                    Общие сведения
                </div>
                <div class="itemtableftmenu" style="display: none; text-align: center;" >
                    <button onclick="showContent('nameobject')">Наименование объекта</button>
                    <button onclick="showContent('about')">Местоположение объекта</button>
                    <button onclick="showContent('contact')">Основание для выполнения работ</button>
                    <button onclick="showContent('worksosn')">Вид градостроительной деятельности</button>
                    <button onclick="showContent('who')">Сведения о земельном участке и землепользователях</button>
                </div>
                <div class="itemtableftmenu" style="display: block; text-align: center;">
                    <button onclick="showContent('idworks')">Идентификационные сведения о заказчике и исполнителе инженерных изысканий</button>
                    <button onclick="showContent('type_of_works')">Виды инженерных изысканий</button>
                </div>
                <button onclick="showContent('drafts')">Черновики</button>
            </div>
        </div>
        <div class="content" id="content">
            <!-- Здесь будет динамичный контент -->
            <p style="font-size: 48px; text-align: center; font-weight: bold;">Добропожаловать в ИГИИС!</p>
            <p></p>
        </div>
        <div class="saved-forms" id="saved-forms">
            <!-- Здесь будет вывод всех сохраненных форм -->
            <p style="font-size: 24px; text-align: center; font-weight: bold;">Сохраненные формы</p>
            <div class="lastblocknameofobject">
            <?php
            $host = '192.168.101.238';
            $dbname = 'z1_db';
            $username = 'postgres';
            $password = 'masterkey';

            try {
                $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
                // Получение последнего id_acc из таблицы usr1
                $sql = "SELECT MAX(id_acc) AS last_id_acc FROM public.usr1";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $lastIdAcc = $result['last_id_acc'];
            
                if (!$lastIdAcc) {
                    die("Не удалось найти последний id_acc.");
                }
            
                $tableName = 'user_data_' . $lastIdAcc;
            
                // Получение данных из последней созданной таблицы
                $sql = "SELECT id, nameofobject, worksofcheck FROM public.$tableName";
                $stmt = $pdo->prepare($sql);
                $stmt->execute();
                $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
                // Вывод данных с добавлением стилей для столбцов
                echo "<style>
                        table {
                            width: 100%;
                            border-collapse: collapse;
                        }
                        th, td {
                            border: 1px solid #ddd;
                            padding: 8px;
                        }
                        th {
                            background-color: #f2f2f2;
                        }
                      </style>";
            
                echo "<table>";
                echo "<tr><th>Name of Object</th>   <th>ID</th><th>Action</th></tr>";
                foreach ($results as $row) {
                    echo "<tr id='row-" . $row['id'] . "'>";
                    echo "<td>" . htmlspecialchars($row['nameofobject']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td><a href='deletetzcreate.php?id=" . $row['id'] . "'>Удалить</a></td>";
                    echo "</tr>";
                }
                echo "</table>";
            
            } catch (PDOException $e) {
                echo "<tr><td colspan='2'>Connection failed: " . $e->getMessage() . "</td></tr>";
            }
            ?>
                <p>Последние сохраненные данные: </p>
            </div>
        </div>
    </div>
    <footer style="background-color: #f4f4f9;">
        <p style="text-align: center;">
            ООО ИГИИС
        </p>
        <div style="text-align: center;">
            <a href="#" class="">Проверка и сохранение данных</a>
            <a href="#" class="">Предварительный просмотр задания</a>
            <a href="#" class="">Подписание задания</a>
            <a href="pdf_create.js" class="">Формирование pdf</a>
            <a href="#" class="">Формирование xml</a>
        </div>
    </footer>
    <script src="main.js"></script>
    <script src="createmodallogin.js"></script>
    
    
</body>
</html>