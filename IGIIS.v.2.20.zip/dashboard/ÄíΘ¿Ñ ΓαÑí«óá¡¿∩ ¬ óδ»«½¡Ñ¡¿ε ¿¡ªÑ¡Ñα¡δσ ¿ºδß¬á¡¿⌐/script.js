document.addEventListener('DOMContentLoaded', function () {
	var coll = document.querySelectorAll('.collapsible')
	coll.forEach(function (button) {
		button.addEventListener('click', function () {
			this.classList.toggle('active')
			var content = this.nextElementSibling
			if (content.style.display === 'block') {
				content.style.display = 'none'
			} else {
				content.style.display = 'block'
			}
		})
	})

	var subColl = document.querySelectorAll('.sub-collapsible')
	subColl.forEach(function (button) {
		button.addEventListener('click', function () {
			this.classList.toggle('active')
			var content = this.nextElementSibling
			if (content.style.display === 'block') {
				content.style.display = 'none'
			} else {
				content.style.display = 'block'
			}
		})
	})

	var quantitativeCheckbox = document.getElementById('quantitative')
	var quantitativeInput = document.getElementById('quantitativeInput')
	quantitativeCheckbox.addEventListener('change', function () {
		if (this.checked) {
			quantitativeInput.classList.remove('hidden')
		} else {
			quantitativeInput.classList.add('hidden')
		}
	})

	var additionalAccuracyCheckbox = document.getElementById('additionalAccuracy')
	var additionalAccuracyInput = document.getElementById(
		'additionalAccuracyInput'
	)
	additionalAccuracyCheckbox.addEventListener('change', function () {
		if (this.checked) {
			additionalAccuracyInput.classList.remove('hidden')
		} else {
			additionalAccuracyInput.classList.add('hidden')
		}
	})

	var scientificSupportCheckbox = document.getElementById('scientificSupport')
	var scientificSupportOptions = document.getElementById(
		'scientificSupportOptions'
	)
	scientificSupportCheckbox.addEventListener('change', function () {
		if (this.checked) {
			scientificSupportOptions.classList.remove('hidden')
		} else {
			scientificSupportOptions.classList.add('hidden')
		}
	})

	var additionalResearchCheckbox = document.getElementById('additionalResearch')
	var additionalResearchInput = document.getElementById(
		'additionalResearchInput'
	)
	additionalResearchCheckbox.addEventListener('change', function () {
		if (this.checked) {
			additionalResearchInput.classList.remove('hidden')
		} else {
			additionalResearchInput.classList.add('hidden')
		}
	})

	var technicalReportCheckbox = document.getElementById('technicalReport')
	var technicalReportInput = document.getElementById('technicalReportInput')
	technicalReportCheckbox.addEventListener('change', function () {
		if (this.checked) {
			technicalReportInput.classList.remove('hidden')
		} else {
			technicalReportInput.classList.add('hidden')
		}
	})

	var forms = document.querySelectorAll('form')
	forms.forEach(function (form) {
		form.addEventListener('submit', function (event) {
			event.preventDefault()
			var formData = new FormData(form)
			var data = {}
			formData.forEach((value, key) => {
				data[key] = value
			})
			localStorage.setItem(form.id, JSON.stringify(data))
			alert('Данные сохранены!')
			form.reset()
		})
	})
})

function saveData(formId) {
	var form = document.getElementById(formId)
	var formData = new FormData(form)
	var data = {}
	formData.forEach((value, key) => {
		data[key] = value
	})
	localStorage.setItem(formId, JSON.stringify(data))
	alert('Данные сохранены!')
	form.reset()
}
