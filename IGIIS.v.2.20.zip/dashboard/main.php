
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ООО "ИГИИС"</title>
    <link rel="stylesheet" href="styles.css.all/main.css">
    <link rel="stylesheet" href="styles.css.all/modal.css">
    <link rel="stylesheet" href="styles.css.all/normalize.css">
    <link rel="icon" href="images/logo_IGIIS_-180x180.gif" type="image/x-icon">
</head>
<body>
    <header>
        <img src="images/logo_IGIIS_-180x180.png" alt="logo" height="80" width="80" style="margin-right: auto; margin-bottom: -30px;">
        <nav>
            <ul>
                <li><a href="main.php" class="active">Главная</a></li>
                <li><a href="aboutus.html">О нас</a></li>
                <li><a href="contacts.html">Контакты</a></li>
                <li><a href="#">Наши соцсети!</a></li>
                <li><a href="login.html"> Вход</a></li>
                <li><a href="templates/table_data.html">ЧЕК </a></li>
                <li><a href="adminlog.php">Admin вход </a></li>
            </ul>
        </nav>
    </header>
    <div class="containermodal">
        <button id="open-modal-btn" style="display: none;">Ознакомьтесь!</button>
    </div>
    <div class="modal open" id="my-modal">
        <div class="modal__box">
            <button class="modal__close-btn" id="close-my-modal-btn">
                <svg width="23" height="25" viewBox="0 0 23 25" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M2.09082 0.03125L22.9999 22.0294L20.909 24.2292L-8.73579e-05 2.23106L2.09082 0.03125Z"
                        fill="#333333" />
                    <path d="M0 22.0295L20.9091 0.0314368L23 2.23125L2.09091 24.2294L0 22.0295Z" fill="#333333" />
                </svg>
            </button>
            <h2>Пользователь, Добропожаловать в базу ИГИИС!</h2>
            <p>
                Ваш аккаунт успешно зарегестрирован!
                <p> 1. Составление задание</p>
                <p> 2. Создание программы</p>
                <p> 3. Создание сметы</p>
                <p> 4. Составление договора</p>
            </p>
            <p>ООО "ИГИИС"</p>
        </div>
    </div>
    <div class="container">
        <h1>Добро пожаловать на сайт ИГИИС цифровые решения</h1>
        <p>Здесь вы можете найти информацию о нашей компании и связаться с нами для получения услуг.</p>
        <div class="service-panel">
            <div class="service">
                <h2>ЗАДАНИЕ</h2>
                <p>Сервис формирования задания на выполнение инженерных изысканий в цифровом виде</p>
                <form action="tzonecreate.php">
                    <input type="submit" value="Перейти" class="bu1"/>
                </form>
            </div>
            <div class="service">
                <h2>ПРОГРАММА</h2>
                <p>Сервис формирования программы инженерных изысканий в цифровом виде</p>
                <form action="programm.html" method="post">
                    <input type="hidden" name="firm" value="ИГИИС цифровые решения">
                    <input type="hidden" name="program" value="Сервис формирования программы инженерных изысканий в цифровом виде">
                    <button type="submit" onclick="window.location.href = '/taskcreate.htm';">Сформировать</button>
                </form>
            </div>
            <div class="service">
                <h2>СМЕТА</h2>
                <p>Сервис формирования сметы на инженерные изыскания на основании программы</p>
                <form action="estimate_service.php" method="post">
                    <input type="hidden" name="firm" value="ИГИИС цифровые решения">
                    <input type="hidden" name="estimate" value="Сервис формирования сметы на инженерные изыскания на основании программы">
                    <button type="submit">Сформировать</button>
                </form>
            </div>
            <div class="service">
                <h2>ДОГОВОР</h2>
                <p>Конструктор договора на выполнение инженерных изысканий</p>
                <form action="contract_constructor.php" method="post">
                    <input type="hidden" name="firm" value="ИГИИС цифровые решения">
                    <input type="hidden" name="contract" value="Конструктор договора на выполнение инженерных изысканий">
                    <button type="submit">Сформировать</button>
                </form>
            </div>
        </div>
    </div>
    <div class="container2">
        <h1>О нашей компании</h1>
        <p>ООО «ИГИИС» — коллектив высококвалифицированных специалистов в области инженерных изысканий в строительстве, обладающих большим опытом проведения всех видов инженерных изысканий: инженерно-геологических, инженерно-геодезических, инженерно-экологических, инженерно-гидрометеорологических, а также работ в области поиска и разведки грунтовых стройматериалов и подземных вод.</p>
        <button class="aboutU" onclick="window.location.href = 'aboutus.html';">Подробнее...</button>
    </div>
    <div class="container3">
        <h1>Контактная информация</h1>
        <p style="font-size: 22px;">Фактический адрес:
            115088, Москва, ул. 1-я Машиностроения, д. 5</p>
        <p style="font-size: 22px;">Телефон: (495) 366-31-89, факс: (495) 366-31-90</p>
        <p style="font-size: 22px;">E-mail: mail@igiis.ru</p>
    </div>
    <footer>
        <div>
            <div>
                <p style="margin-left: 35px; margin-top:140px; color: aliceblue; font-size: 35px;">ИГИИС 2024</p>                 
            </div>
        </div>
    </footer>
    <script defer src="index.js"></script>
</body>
</html>