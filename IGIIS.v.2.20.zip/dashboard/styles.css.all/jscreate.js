document.addEventListener('DOMContentLoaded', function () {
	const app = document.getElementById('app')
	const styleElement = document.getElementById('dynamic-styles')

	const createElement = (tag, attributes = {}, children = []) => {
		const element = document.createElement(tag)
		Object.entries(attributes).forEach(([key, value]) => {
			element.setAttribute(key, value)
		})
		children.forEach(child => {
			if (typeof child === 'string') {
				element.appendChild(document.createTextNode(child))
			} else {
				element.appendChild(child)
			}
		})
		return element
	}

	const addDynamicStyles = () => {
		const styles = `
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
            }

            .container {
                width: 80%;
                margin: 0 auto;
                padding: 20px;
            }

            .accordion {
                background-color: #333;
                color: #fff;
                padding: 20px;
            }

            .accordion-item {
                margin-bottom: 20px;
            }

            .accordion-button {
                background-color: #444;
                color: #fff;
                padding: 10px;
                width: 100%;
                border: none;
                text-align: left;
                cursor: pointer;
                font-size: 18px;
            }

            .accordion-button:focus {
                outline: none;
            }

            .panel {
                display: none;
                background-color: #fff;
                color: #000;
                padding: 20px;
                margin-top: 10px;
            }

            .panel.show {
                display: block;
            }

            form {
                display: flex;
                flex-direction: column;
            }

            form label {
                margin: 10px 0 5px;
            }

            form input, form select, form button {
                padding: 10px;
                margin-bottom: 20px;
                border: 1px solid #ccc;
                border-radius: 5px;
                font-size: 16px;
                width: 100%;
                box-sizing: border-box;
            }

            form button {
                background-color: #333;
                color: #fff;
                border: none;
                cursor: pointer;
            }

            form button:hover {
                background-color: #555;
            }
        `
		styleElement.textContent = styles
	}

	const createForm = (id, title) => {
		const form = createElement('form', {}, [
			createElement('label', { for: `${id}-name` }, [
				'Наименование организации/ИП:',
			]),
			createElement('input', {
				type: 'text',
				id: `${id}-name`,
				name: `${id}-name`,
				required: true,
			}),

			createElement('label', {}, ['Реквизиты:']),
			createElement('input', {
				type: 'text',
				id: `${id}-requisites`,
				name: `${id}-requisites`,
				placeholder: 'ИНН',
				required: true,
			}),

			createElement('label', {}, ['Юридический адрес:']),
			createElement('input', {
				type: 'text',
				id: `${id}-ogrn`,
				name: `${id}-ogrn`,
				placeholder: 'ОГРН',
				required: true,
			}),

			createElement('label', { for: `${id}-country` }, ['Страна:']),
			createElement(
				'select',
				{ id: `${id}-country`, name: `${id}-country` },
				[]
			),

			createElement('label', { for: `${id}-address` }, ['Фактический адрес:']),
			createElement('input', {
				type: 'text',
				id: `${id}-address`,
				name: `${id}-address`,
				required: true,
			}),

			createElement('label', { for: `${id}-email` }, ['Email:']),
			createElement('input', {
				type: 'email',
				id: `${id}-email`,
				name: `${id}-email`,
				required: true,
			}),

			createElement('label', { for: `${id}-phone` }, ['Телефон:']),
			createElement('input', {
				type: 'tel',
				id: `${id}-phone`,
				name: `${id}-phone`,
				required: true,
			}),

			createElement('label', { for: `${id}-contact` }, ['Контактное лицо:']),
			createElement('input', {
				type: 'text',
				id: `${id}-contact`,
				name: `${id}-contact`,
				required: true,
			}),

			createElement('button', { type: 'submit' }, ['Сохранить']),
		])

		const panel = createElement('div', { class: 'panel', id }, [form])
		const button = createElement(
			'button',
			{ class: 'accordion-button', onclick: `toggleAccordion('${id}')` },
			[title]
		)
		const accordionItem = createElement('div', { class: 'accordion-item' }, [
			button,
			panel,
		])

		return accordionItem
	}

	const countries = [
        "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda", "Argentina", 
        "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", 
        "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", 
        "Botswana", "Brazil", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", 
        "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China", "Colombia", "Comoros", 
        "Congo, Democratic Republic of the", "Congo, Republic of the", "Costa Rica", "Cote d'Ivoire", 
        "Croatia", "Cuba", "Cyprus", "Czech Republic", "Denmark", "Djibouti", "Dominica", "Dominican Republic", 
        "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", 
        "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", 
        "Grenada", "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras", "Hungary", 
        "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Israel", "Italy", "Jamaica", "Japan", 
        "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", 
        "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", 
        "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", 
        "Marshall Islands", "Mauritania", "Mauritius", "Mexico", "Micronesia", "Moldova", "Monaco", 
        "Mongolia", "Montenegro", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", 
        "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway", 
        "Oman", "Pakistan", "Palau", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", 
        "Poland", "Portugal", "Qatar", "Romania", "Russia", "Rwanda", "Saint Kitts and Nevis", 
        "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", 
        "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", 
        "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Sudan", "Spain", "Sri Lanka", 
        "Sudan", "Suriname", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", 
        "Thailand", "Timor-Leste", "Togo", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", 
        "Turkmenistan", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", 
        "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", 
        "Yemen", "Zambia", "Zimbabwe"
    ];

	const accordion = createElement('div', { class: 'accordion' }, [
		createElement('div', { class: 'accordion-item' }, [
			createElement('h2', {}, [
				'Идентификационные сведения о заказчике и исполнителе инженерных изысканий',
			]),
		]),
		createForm('customer', 'Сведения о заказчике'),
		createForm('executor', 'Сведения об исполнителе'),
	])

	const container = createElement('div', { class: 'container' }, [accordion])

	addDynamicStyles()
	app.appendChild(container)

	// Добавление стран в выпадающие списки
	const customerCountrySelect = document.getElementById('customer-country')
	const executorCountrySelect = document.getElementById('executor-country')

	if (customerCountrySelect && executorCountrySelect) {
		countries.forEach(country => {
			let option = document.createElement('option')
			option.value = country
			option.textContent = country
			customerCountrySelect.appendChild(option)
			executorCountrySelect.appendChild(option.cloneNode(true))
		})
	} else {
		console.error('Один из элементов select не найден')
	}
})

function toggleAccordion(id) {
	const panel = document.getElementById(id)
	panel.classList.toggle('show')
}
