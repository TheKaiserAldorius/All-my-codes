<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<?php
// Подключение к базе данных
$conn = pg_connect("dbname=z1_db user=postgres password=masterkey");

// Проверка подключения
if (!$conn) {
    die("Ошибка подключения: " . pg_last_error());
}

// Обработка POST-запроса для сохранения изменений
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $new_value = $_POST['new_value'];
    $query = "UPDATE public.id_workstation SET workofcheck = $1 WHERE id = $2";
    $result = pg_query_params($conn, $query, array($new_value, $id));
    if (!$result) {
        die("Ошибка выполнения запроса: " . pg_last_error());
    }
    header("Location: index.php");
    exit();
}

// Получение данных из таблицы
$query = "SELECT * FROM public.id_workstation";
$result = pg_query($conn, $query);
if (!$result) {
    die("Ошибка выполнения запроса: " . pg_last_error());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Черновики</title>
</head>
<body>
    <h1>Черновики</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Work of Check</th>
            <th>Действия</th>
        </tr>
        <?php while ($row = pg_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['workofcheck']; ?></td>
            <td>
                <form method="post" action="index.php">
                    <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                    <input type="text" name="new_value" value="<?php echo $row['workofcheck']; ?>">
                    <button type="submit">Сохранить</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>

<?php
// Закрытие соединения с базой данных
pg_close($conn);
?>