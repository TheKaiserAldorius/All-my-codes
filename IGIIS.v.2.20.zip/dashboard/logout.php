<?php
session_start();

// Уничтожение сессии
session_destroy();
header('Location: main.php');
exit();
?>