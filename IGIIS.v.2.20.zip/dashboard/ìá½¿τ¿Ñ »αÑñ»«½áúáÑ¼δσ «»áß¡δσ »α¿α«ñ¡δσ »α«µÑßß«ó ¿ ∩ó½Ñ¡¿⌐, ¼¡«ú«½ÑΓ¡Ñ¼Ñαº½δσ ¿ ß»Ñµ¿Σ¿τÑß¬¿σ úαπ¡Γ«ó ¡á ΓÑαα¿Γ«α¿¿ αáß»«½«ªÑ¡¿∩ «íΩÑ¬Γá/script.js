document.getElementById('toggleButton').addEventListener('click', function () {
	var content = document.getElementById('content')
	if (content.style.display === 'none') {
		content.style.display = 'block'
	} else {
		content.style.display = 'none'
	}
})

document
	.getElementById('loadDataButton')
	.addEventListener('click', function () {
		alert('Данные атласа загружаются...')
	})

document
	.getElementById('processForm')
	.addEventListener('submit', function (event) {
		event.preventDefault()
		alert('Данные сохранены!')
	})
