function toggleAccordion(element) {
	element.classList.toggle('active')
	const content = element.nextElementSibling
	content.style.display = content.style.display === 'none' ? 'block' : 'none'
}

function openTab(event, tabName) {
	const tabContents = document.querySelectorAll('.tab-content')
	const tabButtons = document.querySelectorAll('.tab-button')

	tabContents.forEach(content => content.classList.remove('active'))
	tabButtons.forEach(button => button.classList.remove('active'))

	document.getElementById(tabName).classList.add('active')
	event.currentTarget.classList.add('active')
}

function toggleExtraFields(fieldId) {
	const field = document.getElementById(fieldId)
	field.style.display = field.style.display === 'none' ? 'block' : 'none'
}

document.addEventListener('DOMContentLoaded', () => {
	const topographicMapsCheckbox = document.getElementById('topographicMaps')
	const topographicPlansCheckbox = document.getElementById('topographicPlans')
	const orthoImagesCheckbox = document.getElementById('orthoImages')
	const specialMapsCheckbox = document.getElementById('specialMaps')

	topographicMapsCheckbox.addEventListener('change', () =>
		toggleExtraFields('topographicMapsFields')
	)
	topographicPlansCheckbox.addEventListener('change', () =>
		toggleExtraFields('topographicPlansFields')
	)
	orthoImagesCheckbox.addEventListener('change', () =>
		toggleExtraFields('orthoImagesFields')
	)
	specialMapsCheckbox.addEventListener('change', () =>
		toggleExtraFields('specialMapsFields')
	)
})
function toggleForm(formId) {
	const form = document.getElementById(formId)
	if (form.style.display === 'none') {
		form.style.display = 'block'
	} else {
		form.style.display = 'none'
	}
}

function toggleTab(tabId) {
	const tabs = document.querySelectorAll('.tab-content')
	tabs.forEach(tab => {
		tab.style.display = 'block'
	})
	document.getElementById(tabId).style.display = 'none'
}

function toggleAdditionalFields() {
	const additionalFields = document.getElementById('additionalFields')
	const checkbox1 = document.getElementById('checkbox1')
	if (checkbox1.checked) {
		additionalFields.style.display = 'none'
	} else {
		additionalFields.style.display = 'block'
	}
}
function toggleForm(formId) {
	const form = document.getElementById(formId)
	if (form.style.display === 'block') {
		form.style.display = 'none'
	} else {
		form.style.display = 'block'
	}
}

function toggleTab(tabId) {
	const tabs = document.querySelectorAll('.tab-content')
	tabs.forEach(tab => {
		tab.style.display = 'none'
	})
	document.getElementById(tabId).style.display = 'block'
}

function toggleAdditionalFields() {
	const additionalFields = document.getElementById('additionalFields')
	const checkbox1 = document.getElementById('checkbox1')
	if (checkbox1.checked) {
		additionalFields.style.display = 'none'
	} else {
		additionalFields.style.display = 'block'
	}
}
