<?php
$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получение всех данных из таблицы id_workstation
    $sql = "SELECT id, nameofobject, worksofcheck FROM public.id_workstation";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Вывод данных с добавлением стилей для столбцов
    echo "<style>
            table {
                width: 100%;
                border-collapse: collapse;
            }
            th, td {
                border: 1px solid #ddd;
                padding: 8px;
            }
            th {
                background-color: #f2f2f2;
            }
          </style>";

    echo "<table>";
    echo "<tr><th>Name of Object</th><th>Works of Check</th><th>ID</th><th>Action</th></tr>";
    foreach ($results as $row) {
        echo "<tr id='row-" . $row['id'] . "'>";
        echo "<td>" . htmlspecialchars($row['nameofobject']) . "</td>";
        echo "<td>" . htmlspecialchars($row['worksofcheck']) . "</td>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td><a href='delete_row.php?id=" . $row['id'] . "'>Удалить</a></td>";
        echo "</tr>";
    }
    echo "</table>";

} catch (PDOException $e) {
    echo "<tr><td colspan='2'>Connection failed: " . $e->getMessage() . "</td></tr>";
}
?>