document.addEventListener('DOMContentLoaded', function () {
	var coll = document.querySelector('.collapsible')
	var content = document.querySelector('.content')

	coll.addEventListener('click', function () {
		this.classList.toggle('active')
		if (content.style.display === 'block') {
			content.style.display = 'none'
		} else {
			content.style.display = 'block'
		}
	})

	var form = document.getElementById('infoForm')
	form.addEventListener('submit', function (event) {
		event.preventDefault()

		var formData = new FormData(form)
		var data = {}
		formData.forEach((value, key) => {
			data[key] = value
		})

		localStorage.setItem('formData', JSON.stringify(data))
		alert('Данные сохранены!')
		form.reset()
	})
})
