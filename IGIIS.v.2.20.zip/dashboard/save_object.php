<?php
session_start();

// Проверка, залогинен ли пользователь
if (!isset($_SESSION['user_email'])) {
    echo json_encode(['success' => false, 'message' => 'Пользователь не залогинен']);
    exit();
}

$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Получение последнего id_acc из таблицы usr1
    $sql = "SELECT MAX(id_acc) AS last_id_acc FROM public.usr1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $lastIdAcc = $result['last_id_acc'];

    if (!$lastIdAcc) {
        echo json_encode(['success' => false, 'message' => 'Не удалось найти последний id_acc']);
        exit();
    }

    $tableName = 'user_data_' . $lastIdAcc;

    // Получение данных из POST запроса
    $inputData = json_decode(file_get_contents('php://input'), true);
    $objectName = $inputData['objectName'] ?? '';

    if (empty($objectName)) {
        echo json_encode(['success' => false, 'message' => 'Наименование объекта не может быть пустым']);
        exit();
    }

    // Вставка данных в таблицу
    $sql = "INSERT INTO public.$tableName (nameofobject) VALUES (:nameofobject)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['nameofobject' => $objectName]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>