function toggleForm(geoStudyId) {
	var form = document.getElementById(geoStudyId)
	if (form.style.display === 'none' || form.style.display === '') {
		form.style.display = 'block'
	} else {
		form.style.display = 'none'
	}
}

function toggleTab(geoStudyId) {
	var tabs = document.getElementsByClassName('tab-content')
	for (var i = 0; i < tabs.length; i++) {
		tabs[i].style.display = 'none'
	}
	var tab = document.getElementById(geoStudyId)
	if (tab.style.display === 'none' || tab.style.display === '') {
		tab.style.display = 'block'
	} else {
		tab.style.display = 'none'
	}
}

function toggleForm(formId) {
	var form = document.getElementById(formId)
	if (form.style.display === 'none' || form.style.display === '') {
		form.style.display = 'block'
	} else {
		form.style.display = 'none'
	}
}

function toggleTab(tabId) {
	var tabs = document.getElementsByClassName('tab-content')
	for (var i = 0; i < tabs.length; i++) {
		tabs[i].style.display = 'none'
	}
	var tab = document.getElementById(tabId)
	if (tab.style.display === 'none' || tab.style.display === '') {
		tab.style.display = 'block'
	} else {
		tab.style.display = 'none'
	}
}

document.addEventListener('DOMContentLoaded', event => {
	var tabButtons = document.querySelectorAll('.tab-button')
	tabButtons.forEach(button => {
		button.addEventListener('click', () => {
			var tabContents = document.querySelectorAll('.tab-content')
			tabContents.forEach(content => {
				content.style.display = 'none'
			})
			var tabId = button.getAttribute('data-tab')
			document.getElementById(tabId).style.display = 'block'
		})
	})
})
