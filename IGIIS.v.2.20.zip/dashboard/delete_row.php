<?php
// Параметры подключения к базе данных
$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

$id_workstation = $_GET['id_workstation'];

// Создание подключения
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// SQL-запрос для удаления строки
$sql = "DELETE FROM nameOFobject WHERE id_workstation = ?";

// Подготовка и выполнение запроса
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $id_workstation);
    if ($stmt->execute()) {
        echo "Строка успешно удалена.";
    } else {
        echo "Ошибка при удалении строки: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Ошибка подготовки запроса: " . $conn->error;
}

// Закрытие подключения
$conn->close();
?>