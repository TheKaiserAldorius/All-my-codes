<?php
session_start();

// Параметры подключения к базе данных
$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

// Создание подключения к базе данных
try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Не удалось подключиться к базе данных: " . $e->getMessage());
}

// Получение данных из формы
$loginEmail = $_POST['loginEmail'];
$loginPassword = $_POST['loginPassword'];

// Подготовка и выполнение SQL-запроса для поиска пользователя
try {
    $sql = "SELECT id_acc, email, password FROM public.usr1 WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['email' => $loginEmail]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Проверка пароля
        if ($loginPassword === $user['password']) {
            // Установка сессии
            $_SESSION['user_email'] = $user['email']; // Сохраняем email в сессию как логин

            // Проверка и создание таблицы для пользователя
            $userId = $user['id_acc'];
            $tableName = 'user_data_' . $userId;

            // Проверка существования таблицы
            $checkTableSql = "SELECT EXISTS (
                SELECT FROM information_schema.tables 
                WHERE table_schema = 'public' 
                AND table_name = :table_name
            )";
            $checkStmt = $pdo->prepare($checkTableSql);
            $checkStmt->execute(['table_name' => $tableName]);
            $tableExists = $checkStmt->fetchColumn();

            if (!$tableExists) {
                $createTableSql = "CREATE TABLE public.$tableName (
                    id SERIAL PRIMARY KEY,
                    nameofobject TEXT,
                    worksofcheck TEXT,
                    sity TEXT,
                    place TEXT,
                    house TEXT
                )";
                $pdo->exec($createTableSql);
            }

            // Пароль верный, перенаправление на главную страницу
            header("Location: tzonecreate.php");
            exit();
        } else {
            echo "Неверный пароль.";
        }
    } else {
        echo "Пользователь с таким email не найден.";
    }
} catch (PDOException $e) {
    die("Ошибка при выполнении запроса: " . $e->getMessage());
}
?>