document.addEventListener('DOMContentLoaded', () => {
	showRegistrationForm()
})

function showRegistrationForm() {
	document.getElementById('registrationForm').classList.add('active')
	document.getElementById('loginForm').classList.remove('active')
	document.getElementById('content').style.display = 'none'
}

function showLoginForm() {
	document.getElementById('registrationForm').classList.remove('active')
	document.getElementById('loginForm').classList.add('active')
	document.getElementById('content').style.display = 'none'
}

function showContent() {
	document.getElementById('registrationForm').classList.remove('active')
	document.getElementById('loginForm').classList.remove('active')
	document.getElementById('content').style.display = 'block'
}

function register() {
	const email = document.getElementById('regEmail').value
	const speciality = document.getElementById('regSpeciality').value
	const password = document.getElementById('regPassword').value
	const confirmPassword = document.getElementById('regConfirmPassword').value

	if (password !== confirmPassword) {
		alert('Пароли не совпадают')
		return
	}

	localStorage.setItem('email', email)
	localStorage.setItem('speciality', speciality)
	localStorage.setItem('password', password)

	showLoginForm()
}

function login() {
	const email = document.getElementById('loginEmail').value
	const password = document.getElementById('loginPassword').value

	const storedEmail = localStorage.getItem('email')
	const storedPassword = localStorage.getItem('password')

	if (email === storedEmail && password === storedPassword) {
		showContent()
	} else {
		alert('Неверный email или пароль')
	}
}
function validateForm()
{
var x=document.forms["myForm"]["fname"].value;
if (x==null || x=="")
  {
  alert("Необходимо заполнить поле Имя!");
  return false;
  }
}