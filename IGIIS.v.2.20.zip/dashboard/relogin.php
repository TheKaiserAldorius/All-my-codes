<?php
session_start();

// Параметры подключения к базе данных
$host = '192.168.101.238';
$dbname = 'z1_db';
$username = 'postgres';
$password = 'masterkey';

// Создание подключения к базе данных
try {
    $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Не удалось подключиться к базе данных: " . $e->getMessage());
}

// Получение данных из формы
$loginEmail = $_POST['loginEmail'];
$loginPassword = $_POST['loginPassword'];

// Подготовка и выполнение SQL-запроса для поиска пользователя
try {
    $sql = "SELECT id_acc, email, password FROM public.usr1 WHERE email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['email' => $loginEmail]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Проверка пароля
        if (password_verify($loginPassword, $user['password'])) {
            // Установка сессии
            $_SESSION['user_email'] = $user['email']; // Сохраняем email в сессию как логин
            // Пароль верный, перенаправление на главную страницу
            header("Location: main.php");
            exit();
        } else {
            echo "Неверный пароль.";
        }
    } else {
        echo "Пользователь с таким email не найден.";
    }
} catch (PDOException $e) {
    die("Ошибка при выполнении запроса: " . $e->getMessage());
}
?>